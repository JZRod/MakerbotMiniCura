"""Cura plugin entry point for MakerBot Mini Network Tools."""
from . import MakerBotMiniNetwork


def register(app):
    """Register the extension using Cura's plugin entry-point API."""
    return {"extension": MakerBotMiniNetwork.MakerBotMiniNetwork()}
