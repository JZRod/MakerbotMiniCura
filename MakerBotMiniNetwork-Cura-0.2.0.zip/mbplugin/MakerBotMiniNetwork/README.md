# MakerBot Replicator Mini Network Tools for Cura

Version 0.2.0 — experimental diagnostics + native job archive inspector for Cura 5.11 / SDK 8.11.

## New findings from the supplied files

- The sample `.makerbot` is a ZIP container with `print.jsontoolpath`, `meta.json`, and thumbnails.
- The sample metadata identifies `bot_type: mini_4`, a 100 × 100 × 125 mm build volume, and a 0.4 mm nozzle.
- The packet capture shows a TCP 9999 JSON-RPC control channel. Observed requests include `print` with `filepath` and `transfer_wait`, and `put_init` with `block_size`, `file_id`, and `file_path`.

## Features

- Adds **Extensions → MakerBot Mini Network Tools…**.
- Tests TCP ports 80, 443, and 9999 for a supplied printer IP.
- Performs a conservative UDP broadcast probe (firmware-dependent; not guaranteed to discover the printer).
- Opens a `.makerbot` file and reports archive entries, metadata, toolpath command counts, and sample commands.

## Important limitations

This release does **not** yet generate a MakerBot toolpath from Cura G-code and does **not** upload/start jobs. The packet capture exposes part of the control protocol, but the complete transfer framing, block acknowledgement/retry rules, and exact job creation semantics have not been validated. The native JSON toolpath includes MakerBot-specific motion/extrusion behavior; simply renaming G-code is invalid. No live print command is sent.

## Install on Windows

1. Close Cura.
2. Open `%APPDATA%\cura\5.11\`.
3. Create `plugins\MakerBotMiniNetwork` if needed.
4. Extract the ZIP so `plugin.json`, `__init__.py`, `MakerBotMiniNetwork.py`, and this README are directly inside that folder.
5. Restart Cura and choose **Extensions → MakerBot Mini Network Tools…**.

If it does not load, inspect Cura's log for plugin import errors. This package targets SDK 8.11.0 / PyQt6.

## Next implementation steps

1. Reassemble the TCP 9999 stream to recover the full `put_init` exchange and binary block framing.
2. Determine the exact JSON-RPC and file transfer sequence for a completed job.
3. Implement a G-code-to-MakerBot JSON toolpath converter that maps movement, extrusion, temperature, fan, homing, and end-of-print semantics.
4. Validate against reference jobs and dry-run checks before enabling upload/print-start.
