# MakerBot Replicator Mini Network Tools — Cura 5.12

Version 0.2.1. This is a diagnostics/archive-inspection plugin, not yet a print sender.

## Correct installation for Cura 5.12 on Windows

1. Exit Cura completely.
2. Press `Win+R`, enter `%APPDATA%\\cura\\5.12\\plugins`, and press Enter. If `plugins` does not exist, create it.
3. Extract this ZIP. The resulting layout must be exactly:

   `%APPDATA%\\cura\\5.12\\plugins\\MakerBotMiniNetwork\\plugin.json`

   `%APPDATA%\\cura\\5.12\\plugins\\MakerBotMiniNetwork\\__init__.py`

   `%APPDATA%\\cura\\5.12\\plugins\\MakerBotMiniNetwork\\MakerBotMiniNetwork.py`

   Do not leave an extra `mbplugin` or another nested `MakerBotMiniNetwork` folder.
4. Start Cura and look under **Extensions → MakerBot Mini Network Tools…**.

This build explicitly declares SDK `8.12.0`, used by Cura 5.12.x, and registers its extension through Cura's `register(app)` entry point.

## Features

- TCP reachability checks for ports 80, 443, and 9999.
- UDP broadcast discovery probe (firmware/network dependent).
- Read-only inspection of `.makerbot` ZIP containers, metadata, and JSON toolpath command counts.

## Limitations

This build does not yet convert Cura G-code to MakerBot JSON toolpath or upload/start prints. Do not treat it as a complete printing workflow.

## If it still does not appear

Open **Help → Show Configuration Folder** (wording can vary), then locate `cura.log` in the Cura configuration folder. Search the log for `MakerBotMiniNetwork`, `plugin`, `Traceback`, or `SDK`. Share the relevant error lines so the loading failure can be diagnosed.
