# Protocol notes from user-provided capture

Capture endpoints observed: printer `192.168.68.75:9999`, desktop `192.168.68.52:<ephemeral>`.

Observed JSON-RPC examples (redacted to relevant fields):

- Desktop request: `{"id":29,"jsonrpc":"2.0","method":"print","params":{"filepath":"1-20mm_Calibration_Box.makerbot","transfer_wait":true}}`
- Desktop request: `{"id":30,"jsonrpc":"2.0","method":"put_init","params":{"block_size":32768,"file_id":"1","file_path":"/current_thing/1-20...makerbot"}}`
- Desktop also requested `get_cloud_services_info` and `request_camera_stream`.

These observations show the JSON-RPC control channel and a 32768-byte transfer block size. They do not, by themselves, establish the complete binary transfer framing, acknowledgements, file finalization, or whether `print` is called before or after upload in all cases. Implementing a sender from these snippets alone would be guesswork, so this release intentionally stops at inspection and diagnostics.
