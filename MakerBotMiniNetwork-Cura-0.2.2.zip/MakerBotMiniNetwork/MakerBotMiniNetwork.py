"""Network diagnostics and native job inspection for the original MakerBot Mini.

This intentionally does not upload/start jobs. The supplied capture shows the
JSON-RPC control channel, but does not yet establish the complete file-transfer
framing/acknowledgement sequence needed to implement a safe sender.
"""
import json
import os
import socket
import threading
import zipfile
from collections import Counter

from PyQt6.QtCore import QObject, pyqtSignal
from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QTextEdit, QMessageBox, QFileDialog)
from UM.Extension import Extension


class _WorkerSignals(QObject):
    line = pyqtSignal(str)
    finished = pyqtSignal()


def inspect_makerbot(path):
    """Read-only inspection of a .makerbot ZIP container."""
    lines = ["File: %s" % os.path.basename(path), "Size: %s bytes" % os.path.getsize(path)]
    with zipfile.ZipFile(path, "r") as archive:
        names = archive.namelist()
        lines.append("\nArchive entries:")
        for info in archive.infolist():
            lines.append("  %s (%s bytes)" % (info.filename, info.file_size))
        if "meta.json" not in names or "print.jsontoolpath" not in names:
            raise ValueError("Missing meta.json and/or print.jsontoolpath. This does not look like a standard MakerBot job.")
        meta = json.loads(archive.read("meta.json").decode("utf-8-sig"))
        lines.append("\nMetadata summary:")
        for key in ("bot_type", "grue_version", "material", "layer_height", "duration_s",
                    "commanded_duration_s", "extruder_temperature", "extrusion_distance_mm"):
            if key in meta:
                lines.append("  %s: %s" % (key, meta[key]))
        bbox = meta.get("bounding_box")
        if bbox:
            lines.append("  bounding_box: %s" % json.dumps(bbox, sort_keys=True))
        raw = archive.read("print.jsontoolpath")
        toolpath = json.loads(raw.decode("utf-8-sig"))
        if not isinstance(toolpath, list):
            raise ValueError("print.jsontoolpath root is not a JSON command list.")
        functions = Counter()
        examples = {}
        for item in toolpath:
            command = item.get("command", {}) if isinstance(item, dict) else {}
            fn = command.get("function", "<missing>")
            functions[fn] += 1
            examples.setdefault(fn, command)
        lines.append("\nToolpath: %d commands, %d bytes" % (len(toolpath), len(raw)))
        lines.append("Command types:")
        for fn, count in functions.most_common():
            lines.append("  %s: %d" % (fn, count))
        lines.append("\nFirst commands (read-only):")
        for item in toolpath[:8]:
            lines.append("  " + json.dumps(item, separators=(",", ":"))[:500])
        lines.append("\nValidation: ZIP readable; metadata JSON readable; toolpath JSON readable.")
        lines.append("This validates the container only; it does not certify that a converted Cura job is safe to print.")
    return "\n".join(lines)


class MakerBotMiniNetwork(Extension):
    def __init__(self):
        super().__init__()
        self.addMenuItem("MakerBot Mini Network Tools…", self.show_dialog)

    def show_dialog(self):
        dialog = QDialog()
        dialog.setWindowTitle("MakerBot Replicator Mini — Network Tools")
        dialog.resize(700, 570)
        layout = QVBoxLayout(dialog)
        layout.addWidget(QLabel(
            "Original Replicator Mini diagnostics and .makerbot archive inspection. "
            "This build does not upload or start prints."
        ))
        row = QHBoxLayout()
        row.addWidget(QLabel("Printer IP:"))
        ip_edit = QLineEdit()
        ip_edit.setPlaceholderText("e.g. 192.168.1.42")
        row.addWidget(ip_edit)
        layout.addLayout(row)
        buttons = QHBoxLayout()
        discover_btn = QPushButton("Discover on LAN")
        test_btn = QPushButton("Test IP / Ports")
        inspect_btn = QPushButton("Inspect .makerbot…")
        buttons.addWidget(discover_btn)
        buttons.addWidget(test_btn)
        buttons.addWidget(inspect_btn)
        layout.addLayout(buttons)
        output = QTextEdit()
        output.setReadOnly(True)
        output.setPlainText(
            "Findings incorporated from the supplied sample and packet capture:\n"
            "• Job container is ZIP-based: meta.json + print.jsontoolpath + thumbnails.\n"
            "• Example profile identifies bot_type=mini_4; build volume 100 × 100 × 125 mm.\n"
            "• TCP 9999 carries JSON-RPC control messages in the capture.\n"
            "• Capture includes print(filepath, transfer_wait=true) and put_init requests.\n\n"
            "The complete upload framing, block acknowledgements, and job-generation conversion "
            "are not yet validated; no print command will be sent by this tool.\n\n"
            "Known ports to test: TCP 80, 443, 9999; legacy UDP discovery may depend on firmware/network."
        )
        layout.addWidget(output)
        note = QLabel("Safety: do not send a converted job to the printer until the toolpath conversion and transfer protocol have been validated.")
        note.setWordWrap(True)
        layout.addWidget(note)
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(dialog.accept)
        layout.addWidget(close_btn)

        def append(text):
            output.append(text)

        discovery_signals = _WorkerSignals()
        port_signals = _WorkerSignals()
        discovery_signals.line.connect(append)
        discovery_signals.finished.connect(lambda: discover_btn.setEnabled(True))
        port_signals.line.connect(append)
        port_signals.finished.connect(lambda: test_btn.setEnabled(True))

        def discover():
            discover_btn.setEnabled(False)
            append("\nStarting UDP discovery probe…")
            def worker():
                lines = []
                sock = None
                try:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
                    sock.settimeout(2.5)
                    try:
                        sock.bind(("", 12308))
                    except OSError:
                        sock.bind(("", 0))
                        lines.append("Could not bind UDP 12308; listening on an ephemeral port instead.")
                    sock.sendto(b"", ("255.255.255.255", 12307))
                    lines.append("Sent empty UDP broadcast probe to 255.255.255.255:12307; this is diagnostic only.")
                    seen = set()
                    while True:
                        try: data, addr = sock.recvfrom(8192)
                        except socket.timeout: break
                        key = (addr[0], data[:256])
                        if key in seen: continue
                        seen.add(key)
                        try: summary = json.dumps(json.loads(data.decode("utf-8", "replace")), ensure_ascii=False)[:500]
                        except Exception: summary = repr(data[:300])
                        lines.append("UDP response from %s: %s" % (addr[0], summary))
                    if not seen:
                        lines.append("No UDP responses. Use the IP shown in MakerBot Desktop and test ports instead.")
                except Exception as exc: lines.append("Discovery error: %s" % exc)
                finally:
                    if sock: sock.close()
                for line in lines: discovery_signals.line.emit(line)
                discovery_signals.finished.emit()
            threading.Thread(target=worker, daemon=True).start()

        def test_ports():
            host = ip_edit.text().strip()
            try: socket.inet_aton(host)
            except OSError:
                QMessageBox.warning(dialog, "Invalid IP address", "Enter a valid IPv4 address first.")
                return
            test_btn.setEnabled(False)
            append("\nTesting %s…" % host)
            def worker():
                lines = []
                for port in (80, 443, 9999):
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(1.5)
                    try:
                        sock.connect((host, port))
                        lines.append("TCP %d: reachable" % port)
                    except Exception as exc: lines.append("TCP %d: not reachable (%s)" % (port, exc))
                    finally: sock.close()
                lines.append("Reachability does not prove a print upload will work.")
                for line in lines: port_signals.line.emit(line)
                port_signals.finished.emit()
            threading.Thread(target=worker, daemon=True).start()

        def inspect_job():
            path, _ = QFileDialog.getOpenFileName(dialog, "Select a MakerBot job", "", "MakerBot jobs (*.makerbot);;ZIP files (*.zip);;All files (*)")
            if not path: return
            try:
                report = inspect_makerbot(path)
                output.append("\n--- JOB INSPECTION ---\n" + report + "\n--- END INSPECTION ---")
            except Exception as exc:
                QMessageBox.critical(dialog, "Could not inspect job", str(exc))
                output.append("\nInspection failed: %s" % exc)

        discover_btn.clicked.connect(discover)
        test_btn.clicked.connect(test_ports)
        inspect_btn.clicked.connect(inspect_job)
        dialog.exec()
