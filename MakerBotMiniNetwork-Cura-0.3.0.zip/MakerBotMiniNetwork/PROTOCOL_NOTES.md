# Protocol and file-format notes

- Known-good sample archive is ZIP-compatible and contains `meta.json`, `print.jsontoolpath`, and three thumbnail PNGs.
- Sample metadata identifies `bot_type: mini_4`, `tool_type: mk13`, 100 x 100 x 125 mm build volume, 0.4 mm nozzle, PLA 1.77 mm filament.
- Toolpath is a JSON array. Observed functions: `move`, `comment`, `toggle_fan`, `fan_duty`, `set_toolhead_temperature`.
- Observed `move` parameters: absolute `x`, `y`, `z`, `a`, and `feedrate`; sample `feedrate` appears in mm/s. Axis-relative flags are in `command.metadata.relative`.
- Network capture showed TCP 9999 JSON-RPC, including `print(filepath, transfer_wait=true)` and `put_init`, but the full block-transfer/ack protocol is not yet established.

These are observations, not a complete protocol specification. Do not assume the experimental converter's output is print-safe.
