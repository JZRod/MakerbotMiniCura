"""MakerBot Mini network tools and experimental G-code converter.

The converter is an early, offline prototype. It does not upload or start jobs.
It supports linear G0/G1 motion and common temperature/fan/mode commands only.
"""
import copy
import json
import math
import os
import re
import socket
import threading
import uuid
import zipfile
from collections import Counter

from PyQt6.QtCore import QObject, pyqtSignal
from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QTextEdit, QMessageBox, QFileDialog, QCheckBox)
from UM.Extension import Extension


class _WorkerSignals(QObject):
    line = pyqtSignal(str)
    finished = pyqtSignal()


def inspect_makerbot(path):
    """Read-only inspection of a .makerbot ZIP container."""
    lines = ["File: %s" % os.path.basename(path), "Size: %s bytes" % os.path.getsize(path)]
    with zipfile.ZipFile(path, "r") as archive:
        names = archive.namelist()
        lines.append("\nArchive entries:")
        for info in archive.infolist():
            lines.append("  %s (%s bytes)" % (info.filename, info.file_size))
        if "meta.json" not in names or "print.jsontoolpath" not in names:
            raise ValueError("Missing meta.json and/or print.jsontoolpath.")
        meta = json.loads(archive.read("meta.json").decode("utf-8-sig"))
        lines.append("\nMetadata summary:")
        for key in ("bot_type", "grue_version", "material", "duration_s",
                    "commanded_duration_s", "extruder_temperature", "extrusion_distance_mm"):
            if key in meta:
                lines.append("  %s: %s" % (key, meta[key]))
        if meta.get("bounding_box"):
            lines.append("  bounding_box: %s" % json.dumps(meta["bounding_box"], sort_keys=True))
        raw = archive.read("print.jsontoolpath")
        toolpath = json.loads(raw.decode("utf-8-sig"))
        if not isinstance(toolpath, list):
            raise ValueError("print.jsontoolpath root is not a JSON command list.")
        functions, examples = Counter(), {}
        for item in toolpath:
            command = item.get("command", {}) if isinstance(item, dict) else {}
            fn = command.get("function", "<missing>")
            functions[fn] += 1
            examples.setdefault(fn, command)
        lines.append("\nToolpath: %d commands, %d bytes" % (len(toolpath), len(raw)))
        lines.append("Command types:")
        for fn, count in functions.most_common():
            lines.append("  %s: %d" % (fn, count))
        lines.append("\nFirst commands (read-only):")
        for item in toolpath[:8]:
            lines.append("  " + json.dumps(item, separators=(",", ":"))[:500])
        lines.append("\nValidation: ZIP readable; metadata JSON readable; toolpath JSON readable.")
        lines.append("Container validation does not certify print safety.")
    return "\n".join(lines)


def _command(function, parameters, tags=None, relative=None):
    metadata = {}
    if relative is not None:
        metadata["relative"] = relative
    return {"command": {"function": function, "metadata": metadata,
                        "parameters": parameters, "tags": tags or []}}


def parse_cura_gcode(gcode_text, center_origin=True):
    """Convert a conservative subset of Cura G-code into Mini JSON commands.

    Cura's usual front-left XY origin is translated to a centered Mini bed by
    subtracting 50 mm. Disable center_origin only when the G-code is already
    expressed in the printer's centered coordinate system.
    """
    commands = []
    x = y = z = e = a_position = 0.0
    absolute_xyz = True
    absolute_e = True
    feed_mm_min = 1200.0
    target_temp = None
    fan_on = False
    fan_duty = None
    min_x = min_y = min_z = float("inf")
    max_x = max_y = max_z = float("-inf")
    positive_extrusion = 0.0
    layers = 0
    warnings = []
    seen_motion = False

    def add_move(nx, ny, nz, ne, feed, tags):
        nonlocal min_x, min_y, min_z, max_x, max_y, max_z, seen_motion
        px = nx - 50.0 if center_origin else nx
        py = ny - 50.0 if center_origin else ny
        if not all(math.isfinite(v) for v in (px, py, nz, ne, feed)):
            raise ValueError("Non-finite value encountered in G-code.")
        if abs(px) > 50.0 or abs(py) > 50.0 or nz < -0.01 or nz > 125.0:
            raise ValueError("Move exceeds the assumed Mini build envelope: X %.2f Y %.2f Z %.2f. Check the XY origin setting and model placement." % (px, py, nz))
        commands.append(_command("move", {"a": round(ne, 6), "feedrate": round(max(feed / 60.0, 0.01), 4),
            "x": round(px, 6), "y": round(py, 6), "z": round(nz, 6)}, tags,
            {"a": False, "x": False, "y": False, "z": False}))
        if "Extrusion Move" in tags:
            min_x, max_x = min(min_x, px), max(max_x, px)
            min_y, max_y = min(min_y, py), max(max_y, py)
            min_z, max_z = min(min_z, nz), max(max_z, nz)
        seen_motion = True

    for line_no, raw in enumerate(gcode_text.splitlines(), 1):
        line = raw.strip()
        if not line:
            continue
        if line.startswith(";"):
            comment = line[1:].strip()
            if comment:
                commands.append(_command("comment", {"comment": comment[:240]}))
                if "LAYER:" in comment.upper():
                    layers += 1
            continue
        # Strip semicolon comments and parenthesized comments.
        line = line.split(";", 1)[0]
        line = re.sub(r"\([^)]*\)", "", line).strip().upper()
        if not line:
            continue
        if "*" in line:
            line = line.split("*", 1)[0]
        words = re.findall(r"([A-Z])\s*(-?(?:\d+(?:\.\d*)?|\.\d+))", line)
        if not words:
            continue
        values = {}
        for letter, number in words:
            values[letter] = float(number)
        code = None
        for letter, number in words:
            if letter == "G" or letter == "M":
                code = (letter, int(float(number)))
                break
        if code is None:
            if "T" in values and int(values["T"]) != 0:
                raise ValueError("Line %d selects tool T%d; the original Mini converter supports only one toolhead." % (line_no, int(values["T"])))
            continue
        letter, number = code
        if "T" in values and int(values["T"]) != 0:
            raise ValueError("Line %d selects tool T%d; the original Mini converter supports only one toolhead." % (line_no, int(values["T"])))
        if letter == "G" and number in (90, 91):
            absolute_xyz = number == 90
        elif letter == "M" and number in (82, 83):
            absolute_e = number == 82
        elif letter == "G" and number in (0, 1):
            old_e = e
            nx = values.get("X", x) if absolute_xyz else x + values.get("X", 0.0)
            ny = values.get("Y", y) if absolute_xyz else y + values.get("Y", 0.0)
            nz = values.get("Z", z) if absolute_xyz else z + values.get("Z", 0.0)
            if "E" in values:
                e = values["E"] if absolute_e else e + values["E"]
            delta_e = e - old_e
            a_position += delta_e
            positive_extrusion += max(delta_e, 0.0)
            if "F" in values:
                feed_mm_min = values["F"]
            tags = ["Travel Move"]
            if delta_e > 0.000001:
                tags = ["Extrusion Move"]
            elif delta_e < -0.000001:
                tags = ["Retract"]
            add_move(nx, ny, nz, a_position, feed_mm_min, tags)
            x, y, z = nx, ny, nz
        elif letter == "M" and number in (104, 109):
            temp = values.get("S", values.get("R"))
            if temp is not None:
                target_temp = temp
                commands.append(_command("set_toolhead_temperature", {"index": 0, "temperature": round(temp, 2)}))
        elif letter == "M" and number == 106:
            s = values.get("S", 255.0)
            duty = max(0.0, min(1.0, s / 255.0))
            if not fan_on:
                commands.append(_command("toggle_fan", {"index": 0, "value": True}))
                fan_on = True
            if fan_duty is None or abs(duty - fan_duty) > 0.001:
                commands.append(_command("fan_duty", {"index": 0, "value": round(duty, 4)}))
                fan_duty = duty
        elif letter == "M" and number == 107:
            if fan_on:
                commands.append(_command("toggle_fan", {"index": 0, "value": False}))
                fan_on = False
            fan_duty = 0.0
        elif letter == "G" and number in (2, 3):
            raise ValueError("Line %d uses arc motion %s%d. Arc interpolation is not implemented; conversion stopped to avoid silently changing the shape." % (line_no, letter, number))
        elif letter == "M" and number in (201, 203, 204, 205, 900):
            warnings.append("Line %d: machine tuning command M%d was ignored." % (line_no, number))
        elif letter == "G" and number == 92:
            # G92 E resets are common in Cura. XYZ resets need offset tracking.
            if any(axis in values for axis in ("X", "Y", "Z")):
                raise ValueError("Line %d contains a G92 XYZ reset. Coordinate-offset tracking is not implemented; conversion stopped." % line_no)
            if "E" in values: e = values["E"]
        elif letter == "G" and number == 28:
            warnings.append("Line %d: G28 homing was omitted; the printer must be homed by its own workflow before any future print test." % line_no)
        elif letter == "G" and number in (10, 11):
            raise ValueError("Line %d uses firmware retract G%d. Firmware-retraction conversion is not implemented." % (line_no, number))
        elif letter == "M" and number in (140, 190):
            pass
        # Other slicer housekeeping commands are intentionally ignored.

    if not seen_motion:
        raise ValueError("No G0/G1 movement commands were found in this G-code file.")
    if not any(c["command"]["function"] == "set_toolhead_temperature" for c in commands):
        warnings.append("No M104/M109 nozzle temperature was found; template metadata temperature was retained.")
    if min_x == float("inf"):
        raise ValueError("No positive extrusion moves were found; refusing to create an empty or travel-only job.")
    bbox = {"x_min": min_x, "x_max": max_x, "y_min": min_y, "y_max": max_y,
            "z_min": min_z, "z_max": max_z}
    stats = {"bbox": bbox, "positive_extrusion_mm": positive_extrusion,
             "layers": layers, "temperature": target_temp, "warnings": warnings}
    return commands, stats


def convert_gcode_to_makerbot(gcode_path, template_path, output_path, center_origin=True):
    """Create an experimental MakerBot archive using a known-good job as metadata template."""
    with open(gcode_path, "r", encoding="utf-8-sig", errors="replace") as handle:
        gcode = handle.read()
    commands, stats = parse_cura_gcode(gcode, center_origin=center_origin)
    with zipfile.ZipFile(template_path, "r") as template:
        names = template.namelist()
        if "meta.json" not in names or "print.jsontoolpath" not in names:
            raise ValueError("Selected template is missing meta.json or print.jsontoolpath.")
        meta = json.loads(template.read("meta.json").decode("utf-8-sig"))
        # Retain the reference's printer/machine configuration and slicer profile,
        # while replacing job-specific fields that can be derived at this stage.
        meta["uuid"] = str(uuid.uuid4())
        meta["total_commands"] = len(commands)
        meta["bounding_box"] = stats["bbox"]
        meta["extrusion_distance_mm"] = round(stats["positive_extrusion_mm"], 5)
        meta["extrusion_distances_mm"] = [round(stats["positive_extrusion_mm"], 5)]
        meta["num_z_layers"] = max(stats["layers"], 1)
        meta["num_z_transitions"] = max(stats["layers"] - 1, 0)
        if stats["temperature"] is not None:
            meta["extruder_temperature"] = stats["temperature"]
            meta["extruder_temperatures"] = [stats["temperature"]]
        # No trustworthy duration or mass estimator is available yet.
        meta["duration_s"] = 0
        meta["commanded_duration_s"] = 0
        meta["extrusion_mass_g"] = 0
        meta["extrusion_masses_g"] = [0]
        out_tmp = output_path + ".tmp"
        with zipfile.ZipFile(out_tmp, "w", compression=zipfile.ZIP_DEFLATED) as out:
            out.writestr("print.jsontoolpath", json.dumps(commands, separators=(",", ":"), ensure_ascii=False))
            out.writestr("meta.json", json.dumps(meta, separators=(",", ":"), ensure_ascii=False))
            # Preserve expected thumbnail filenames for container compatibility.
            # They remain the reference job's images, not previews of this model.
            for name in names:
                if name.startswith("thumbnail_") and name in names:
                    out.writestr(name, template.read(name))
        os.replace(out_tmp, output_path)
    return stats, len(commands)


class MakerBotMiniNetwork(Extension):
    def __init__(self):
        super().__init__()
        self.addMenuItem("MakerBot Mini Network Tools…", self.show_dialog)

    def show_dialog(self):
        dialog = QDialog()
        dialog.setWindowTitle("MakerBot Replicator Mini — Network Tools")
        dialog.resize(760, 650)
        layout = QVBoxLayout(dialog)
        layout.addWidget(QLabel("Original Replicator Mini diagnostics, archive inspection, and experimental offline G-code conversion."))
        row = QHBoxLayout()
        row.addWidget(QLabel("Printer IP:"))
        ip_edit = QLineEdit()
        ip_edit.setPlaceholderText("e.g. 192.168.1.42")
        row.addWidget(ip_edit)
        layout.addLayout(row)
        buttons = QHBoxLayout()
        discover_btn, test_btn, inspect_btn, convert_btn = (QPushButton(t) for t in
            ("Discover on LAN", "Test IP / Ports", "Inspect .makerbot…", "Convert Cura G-code…"))
        for button in (discover_btn, test_btn, inspect_btn, convert_btn):
            buttons.addWidget(button)
        layout.addLayout(buttons)
        center_check = QCheckBox("Translate Cura front-left XY coordinates to centered Mini coordinates (subtract 50 mm)")
        center_check.setChecked(True)
        layout.addWidget(center_check)
        output = QTextEdit()
        output.setReadOnly(True)
        output.setPlainText(
            "Findings from the supplied sample and capture:\n"
            "• .makerbot is ZIP-based: meta.json + print.jsontoolpath + thumbnails.\n"
            "• Example profile: mini_4; build volume 100 × 100 × 125 mm; tool mk13.\n"
            "• TCP 9999 carries JSON-RPC control messages in the capture.\n"
            "• Conversion is experimental and offline only. It does not upload or start prints.\n\n"
            "Converter supports G0/G1, G90/G91, M82/M83, M104/M109, M106/M107, and comments.\n"
            "Arcs, homing, coordinate resets, firmware retraction, and several machine-specific features are not implemented.\n"
        )
        layout.addWidget(output)
        note = QLabel("WARNING: Generated files are experimental. The reference job's thumbnails and machine profile are reused. Do not print until the toolpath, origin, extrusion, temperatures, and printer behavior have been independently validated.")
        note.setWordWrap(True)
        layout.addWidget(note)
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(dialog.accept)
        layout.addWidget(close_btn)

        def append(text):
            output.append(text)

        discovery_signals, port_signals = _WorkerSignals(), _WorkerSignals()
        discovery_signals.line.connect(append)
        discovery_signals.finished.connect(lambda: discover_btn.setEnabled(True))
        port_signals.line.connect(append)
        port_signals.finished.connect(lambda: test_btn.setEnabled(True))

        def discover():
            discover_btn.setEnabled(False)
            append("\nStarting UDP discovery probe…")
            def worker():
                lines, sock = [], None
                try:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
                    sock.settimeout(2.5)
                    try: sock.bind(("", 12308))
                    except OSError:
                        sock.bind(("", 0))
                        lines.append("Could not bind UDP 12308; listening on an ephemeral port instead.")
                    sock.sendto(b"", ("255.255.255.255", 12307))
                    lines.append("Sent empty UDP broadcast probe to 255.255.255.255:12307; diagnostic only.")
                    seen = set()
                    while True:
                        try: data, addr = sock.recvfrom(8192)
                        except socket.timeout: break
                        key = (addr[0], data[:256])
                        if key in seen: continue
                        seen.add(key)
                        try: summary = json.dumps(json.loads(data.decode("utf-8", "replace")), ensure_ascii=False)[:500]
                        except Exception: summary = repr(data[:300])
                        lines.append("UDP response from %s: %s" % (addr[0], summary))
                    if not seen: lines.append("No UDP responses. Use MakerBot Desktop's printer IP and test ports.")
                except Exception as exc: lines.append("Discovery error: %s" % exc)
                finally:
                    if sock: sock.close()
                for item in lines: discovery_signals.line.emit(item)
                discovery_signals.finished.emit()
            threading.Thread(target=worker, daemon=True).start()

        def test_ports():
            host = ip_edit.text().strip()
            try: socket.inet_aton(host)
            except OSError:
                QMessageBox.warning(dialog, "Invalid IP address", "Enter a valid IPv4 address first.")
                return
            test_btn.setEnabled(False)
            append("\nTesting %s…" % host)
            def worker():
                lines = []
                for port in (80, 443, 9999):
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(1.5)
                    try: sock.connect((host, port)); lines.append("TCP %d: reachable" % port)
                    except Exception as exc: lines.append("TCP %d: not reachable (%s)" % (port, exc))
                    finally: sock.close()
                lines.append("Reachability does not prove upload compatibility.")
                for item in lines: port_signals.line.emit(item)
                port_signals.finished.emit()
            threading.Thread(target=worker, daemon=True).start()

        def inspect_job():
            path, _ = QFileDialog.getOpenFileName(dialog, "Select a MakerBot job", "", "MakerBot jobs (*.makerbot);;ZIP files (*.zip);;All files (*)")
            if not path: return
            try: output.append("\n--- JOB INSPECTION ---\n" + inspect_makerbot(path) + "\n--- END INSPECTION ---")
            except Exception as exc:
                QMessageBox.critical(dialog, "Could not inspect job", str(exc))
                output.append("\nInspection failed: %s" % exc)

        def convert_job():
            gcode, _ = QFileDialog.getOpenFileName(dialog, "Select Cura-exported G-code", "", "G-code (*.gcode *.gco *.gc);;All files (*)")
            if not gcode: return
            template, _ = QFileDialog.getOpenFileName(dialog, "Select a known-good Mini .makerbot file", "", "MakerBot jobs (*.makerbot);;ZIP files (*.zip)")
            if not template: return
            suggested = os.path.splitext(gcode)[0] + "_experimental.makerbot"
            target, _ = QFileDialog.getSaveFileName(dialog, "Save experimental MakerBot job", suggested, "MakerBot jobs (*.makerbot)")
            if not target: return
            if not target.lower().endswith(".makerbot"): target += ".makerbot"
            try:
                stats, count = convert_gcode_to_makerbot(gcode, template, target, center_check.isChecked())
                report = ["\n--- EXPERIMENTAL CONVERSION ---", "Output: %s" % target,
                    "Commands: %d" % count, "Bounding box: %s" % json.dumps(stats["bbox"], sort_keys=True),
                    "Positive extrusion: %.3f mm" % stats["positive_extrusion_mm"],
                    "Layer comments detected: %d" % stats["layers"],
                    "NOTE: reference thumbnails/profile are retained; duration/mass are placeholders."]
                report.extend("WARNING: " + w for w in stats["warnings"])
                report.append("DO NOT PRINT this file yet; conversion semantics are not validated.")
                output.append("\n".join(report))
                QMessageBox.information(dialog, "Conversion created", "Experimental archive created. It has not been validated for printing.")
            except Exception as exc:
                QMessageBox.critical(dialog, "Conversion failed", str(exc))
                output.append("\nConversion failed: %s" % exc)

        discover_btn.clicked.connect(discover)
        test_btn.clicked.connect(test_ports)
        inspect_btn.clicked.connect(inspect_job)
        convert_btn.clicked.connect(convert_job)
        dialog.exec()
