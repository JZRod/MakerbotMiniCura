# MakerBot Mini Network Tools for Cura

Experimental Cura 5.12 / SDK 8.12 plugin for the original MakerBot Replicator Mini (`mini_4`).

## Current features

- LAN UDP discovery probe and TCP reachability checks (80, 443, 9999).
- Read-only inspection of `.makerbot` ZIP archives.
- Experimental offline conversion of an exported Cura G-code file to a `.makerbot`-shaped archive using a known-good Mini job as a metadata/profile template.

## Experimental converter limitations

The converter currently handles linear `G0`/`G1`, `G90`/`G91`, `M82`/`M83`, `G92` coordinate resets, `M104`/`M109`, `M106`/`M107`, and comments. Cura's usual front-left XY origin is shifted by -50 mm on X/Y by default. Disable that option only if the G-code already uses centered coordinates.

It does **not** implement arc interpolation (`G2`/`G3`), homing (`G28`), firmware retraction, volumetric extrusion, dual-extruder behavior, machine-specific start/end sequences, reliable print-time/mass estimates, Cura preview thumbnail generation, or verified MakerBot motion semantics. Arc moves cause conversion to stop. The reference job's thumbnails and machine profile are retained as placeholders; they do not represent the converted model. Metadata duration and mass are set to placeholders.

**Do not print converted files.** This is a format/conversion prototype only. It has not been validated against MakerBot Desktop or on a physical printer. The plugin does not upload or start jobs; TCP 9999 transfer framing and acknowledgements remain unimplemented.

## Install

Close Cura. Extract the `MakerBotMiniNetwork` folder from the ZIP into `%APPDATA%/cura/5.12/plugins/`, so `__init__.py` and `plugin.json` are directly inside that folder. Restart Cura.
